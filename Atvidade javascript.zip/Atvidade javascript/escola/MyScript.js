function CalcularMedia(){

    let atvd1 = parseInt(document.getElementById("atvd1").value);
    let atvd2 = parseInt(document.getElementById("atvd2").value);
    let atvd3 = parseInt(document.getElementById("atvd3").value);
    let atvd4 = parseInt(document.getElementById("atvd4").value);
    let freq = parseInt(document.getElementById("freq").value)
    let media = parseInt(document.getElementById("media").value)
     media = (atvd1 + atvd2 + atvd3 + atvd4) /4;


    document.getElementById("media").innerHTML = 'Media Final:' + media.toFixed(1);
        if(media>= 6 && freq >=75)

    {document.getElementById("status").innerHTML= "Aprovado";
} else if (freq <75){
    document.getElementById("status").innerHTML = "Reprovado por frequencia"
}
else{
    document.getElementById("status").innerHTML = "Reprovado por nota"

}







   
}