function calcular(){

    let c = document.getElementById('c').value;
    c = parseFloat(c);

    let j = document.getElementById('j').value;
    j = parseFloat(j);

    
    let t = document.getElementById('t').value;
    t = parseFloat(t);


    let M = c * Math.pow(1 +j,t);

    M = Math.round(M*100)/100;
     

    let lucro = M - c;

    lucro = Math.round(lucro*100)/100;
    document.getElementById('demo').innerHTML = "Montante = " + M + "<br> lucro= " + lucro;





}